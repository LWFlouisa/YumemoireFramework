## Title
Sparks Of Contamination

## Genre
Roguelike / RPS-Like / Survival Horror

## Description
You are a part of a clean up crew to remove filth left over by zombies, but one zombie is more intelligent than is expecting. You have thirty days to clean up the mansion. If you become fully contaminated, its game over.

## Gameplay
Bludgeon - This requires the presence of a mechanical hammer. Find tools.
Scoop    - This requires the presence of a machanical shovel. Find tools.
Strangle - Requires you to take off your shirt to get down and dirty. Find tools.
Light    - This requires the presence of a flashlight, presents randomized rooms.

## Glossary
Do not delete the glossary, as this is considered essential learning how Procedurally Generative Names work.
