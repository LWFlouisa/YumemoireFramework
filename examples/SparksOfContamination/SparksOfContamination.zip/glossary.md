### Word Classes
Le, Anu   - the masculine<br />
La, Ana   - the feminine<br />
Les, Anos - the nuetral

### Elements
Eabon  - Earth<br />
Denki  - Air<br />
Kaiyo  - Water<br />
Tsuchi - Fire<br />
Tenchi - Divine<br />
Shi    - Death

## Gendered Adjectives
les corrompue  - the corrupted
le recupere    - the recovered
le soufflé     - the blown
le carbonise   - the charred / carbonized
la noyee       - the drowned ( feminine )
le noye        - the drowned ( masculine )
le fissure     - the cracked
les abandonnés - the abandoned

## Usage
Anos Eabonos de les fissure - The Cracked Earth
Ana Denka de la noyee - The Air Drowned
